export const mw = (v, d = 0) => (v == null ? "–" : `${Number(v).toLocaleString("en-GB", { maximumFractionDigits: d })} MW`);
export const gw = (v, d = 1) => (v == null ? "–" : `${(v / 1000).toLocaleString("en-GB", { maximumFractionDigits: d })} GW`);
export const pct = (v, d = 1) => (v == null ? "–" : `${Number(v).toFixed(d)}%`);
export const signed = (v, d = 0) => (v == null ? "–" : `${v > 0 ? "+" : ""}${Number(v).toLocaleString("en-GB", { maximumFractionDigits: d })} MW`);
export const longDate = (iso) =>
  new Date(iso + "T12:00:00Z").toLocaleDateString("en-GB", { weekday: "short", day: "numeric", month: "short", year: "numeric" });
export const shortDate = (iso) => new Date(iso + "T12:00:00Z").toLocaleDateString("en-GB", { day: "numeric", month: "short" });
export const londonTime = (iso) =>
  iso ? new Date(iso).toLocaleString("en-GB", { timeZone: "Europe/London", day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }) : "–";

export function downloadCsv(filename, rows) {
  if (!rows.length) return;
  const cols = Object.keys(rows[0]);
  const body = [cols.join(","), ...rows.map((r) => cols.map((c) => r[c] ?? "").join(","))].join("\n");
  const url = URL.createObjectURL(new Blob([body], { type: "text/csv" }));
  const a = Object.assign(document.createElement("a"), { href: url, download: filename });
  a.click();
  URL.revokeObjectURL(url);
}
