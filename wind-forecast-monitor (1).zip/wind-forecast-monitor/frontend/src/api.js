// Single place that talks to the backend. All components go through these functions.
async function get(path) {
  const res = await fetch(path);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.detail || `Request failed (${res.status})`);
  }
  return res.json();
}

const q = (c) => `cutoff_hour=${c.hour}&cutoff_minute=${c.minute}`;

export const api = {
  meta: () => get("/api/meta"),
  decision: (date, cutoff) => get(`/api/decision/${date}?${q(cutoff)}`),
  accuracy: (cutoff) => get(`/api/accuracy?${q(cutoff)}`),
  horizon: () => get("/api/horizon"),
  quality: () => get("/api/quality"),
};
