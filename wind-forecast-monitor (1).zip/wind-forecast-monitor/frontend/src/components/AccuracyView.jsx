import { useEffect, useState } from "react";
import { ComposedChart, BarChart, Bar, Line, Area, XAxis, YAxis, Tooltip, Legend, CartesianGrid, ResponsiveContainer, ReferenceLine } from "recharts";
import { api } from "../api.js";
import Kpi from "./Kpi.jsx";
import { mw, pct, signed, shortDate } from "../format.js";

const grid = <CartesianGrid stroke="#e3e8ef" strokeDasharray="3 3" />;

export default function AccuracyView({ cutoff }) {
  const [acc, setAcc] = useState(null);
  const [hz, setHz] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    setAcc(null); setError(null);
    Promise.all([api.accuracy(cutoff), api.horizon()]).then(([a, h]) => { setAcc(a); setHz(h.buckets); }).catch((e) => setError(e.message));
  }, [cutoff]);

  if (error) return <div className="error">{error}</div>;
  if (!acc) return <div className="loading">Computing accuracy…</div>;

  const o = acc.overall;
  const perDay = acc.perDay.filter((d) => d.n > 0).map((d) => ({ ...d, label: shortDate(d.deliveryDate) }));
  const tod = acc.byTimeOfDay.map((t) => ({ ...t, range: [t.p10, t.p90] }));
  const hist = acc.histogram.map((h) => ({ ...h, label: `${h.from / 1000}` }));
  const worstDay = [...perDay].sort((a, b) => b.mae - a.mae)[0];
  const first = hz?.[0], last = hz?.[hz.length - 1];

  return (
    <>
      <div className="insight">
        Across <strong>{acc.coverage.evaluated.toLocaleString()}</strong> half-hours of January deliveries, the forecast available at {String(acc.cutoff.hour).padStart(2, "0")}:{String(acc.cutoff.minute).padStart(2, "0")} the day before
        was off by <strong>{mw(o.mae)}</strong> on average ({pct(o.wmape)} of wind output) and
        {o.bias > 0 ? " over-predicted" : " under-predicted"} by <strong>{mw(Math.abs(o.bias))}</strong> on average.
        One half-hour in ten, wind fell short of forecast by more than <strong>{mw(o.p90Shortfall)}</strong>
        {worstDay && <>; the hardest day to forecast was delivery on <strong>{worstDay.label}</strong> (MAE {mw(worstDay.mae)}).</>}
      </div>

      <div className="grid">
        <Kpi label="MAE" value={mw(o.mae)} sub={`Median abs error ${mw(o.p50AbsError)}`} highlight />
        <Kpi label="RMSE" value={mw(o.rmse)} sub="Penalises large misses" />
        <Kpi label="Bias (forecast − actual)" value={signed(o.bias)} sub={o.bias > 0 ? "Systematic over-forecast" : "Systematic under-forecast"} />
        <Kpi label="wMAPE" value={pct(o.wmape)} sub={`MAPE ${pct(o.mape)} (actual ≥ 500 MW)`} />
        <Kpi label="P90 shortfall" value={mw(o.p90Shortfall)} sub="Wind below forecast, 1 in 10" />
        <Kpi label="P95 abs error" value={mw(o.p95AbsError)} sub={`Coverage ${acc.coverage.evaluated}/${acc.coverage.targets} periods`} />
      </div>

      <div className="two">
        <div className="card">
          <h3>Error by delivery day</h3>
          <p className="desc">Mean absolute error (bars) and bias (line), MW.</p>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={perDay}>
              {grid}<XAxis dataKey="label" tick={{ fontSize: 11 }} interval={2} /><YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => mw(v)} /><Legend /><ReferenceLine y={0} stroke="#999" />
              <Bar dataKey="mae" name="MAE" fill="#0f9d94" isAnimationActive={false} />
              <Line dataKey="bias" name="Bias" stroke="#c2410c" dot={false} strokeWidth={2} isAnimationActive={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3>Error vs forecast lead time</h3>
          <p className="desc">All published forecasts, grouped by hours between publication and delivery. Day-ahead decisions sit in the {first ? "15–39h" : ""} range.</p>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={hz || []}>
              {grid}<XAxis dataKey="bucket" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => mw(v)} /><Legend />
              <Bar dataKey="mae" name="MAE" fill="#2563eb" isAnimationActive={false} />
              <Bar dataKey="rmse" name="RMSE" fill="#93b4f5" isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
          {first && last && <p className="desc">MAE rises from {mw(first.mae)} ({first.bucket}) to {mw(last.mae)} ({last.bucket}).</p>}
        </div>

        <div className="card">
          <h3>Bias by time of day</h3>
          <p className="desc">Average signed error with 10th–90th percentile range (MW). Above zero = shortfall risk.</p>
          <ResponsiveContainer width="100%" height={300}>
            <ComposedChart data={tod}>
              {grid}<XAxis dataKey="localTime" interval={5} tick={{ fontSize: 11 }} /><YAxis tick={{ fontSize: 12 }} />
              <Tooltip formatter={(v) => (Array.isArray(v) ? `${mw(v[0])} – ${mw(v[1])}` : mw(v))} /><ReferenceLine y={0} stroke="#999" />
              <Area dataKey="range" name="P10–P90" stroke="none" fill="#c2410c" fillOpacity={0.15} isAnimationActive={false} />
              <Line dataKey="bias" name="Mean error" stroke="#c2410c" dot={false} strokeWidth={2} isAnimationActive={false} />
            </ComposedChart>
          </ResponsiveContainer>
        </div>

        <div className="card">
          <h3>Error distribution</h3>
          <p className="desc">Count of half-hours by signed error, GW bins (tails clipped at ±6 GW).</p>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={hist}>
              {grid}<XAxis dataKey="label" tick={{ fontSize: 12 }} /><YAxis tick={{ fontSize: 12 }} />
              <Tooltip labelFormatter={(l) => `${l} GW to +1 GW`} />
              <Bar dataKey="count" name="Half-hours" fill="#0f9d94" isAnimationActive={false} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h3>Daily accuracy table</h3>
        <div className="scroll">
          <table>
            <thead><tr><th>Delivery day</th><th>N</th><th>MAE</th><th>RMSE</th><th>Bias</th><th>wMAPE</th><th>P90 shortfall</th></tr></thead>
            <tbody>
              {perDay.map((d) => (
                <tr key={d.deliveryDate}><td>{d.label}</td><td>{d.n}</td><td>{mw(d.mae)}</td><td>{mw(d.rmse)}</td>
                  <td className={d.bias > 0 ? "pos" : "neg"}>{signed(d.bias)}</td><td>{pct(d.wmape)}</td><td>{mw(d.p90Shortfall)}</td></tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}
