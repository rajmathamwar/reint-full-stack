import { useEffect, useState } from "react";
import { api } from "../api.js";
import Kpi from "./Kpi.jsx";
import { londonTime } from "../format.js";

export default function DataStatus() {
  const [q, setQ] = useState(null);
  const [error, setError] = useState(null);
  useEffect(() => { api.quality().then(setQ).catch((e) => setError(e.message)); }, []);

  if (error) return <div className="error">{error}</div>;
  if (!q) return <div className="loading">Checking data…</div>;

  const { actuals: a, forecasts: f, data } = q;
  const live = !data.synthetic;
  return (
    <>
      <div className={`banner ${q.warnings.length ? "warn" : "info"}`}>
        {q.warnings.length ? (
          <>
            <strong>{q.warnings.length} data-quality warning{q.warnings.length > 1 ? "s" : ""}</strong>
            <ul style={{ margin: "6px 0 0", paddingLeft: 20 }}>{q.warnings.map((w) => <li key={w}>{w}</li>)}</ul>
          </>
        ) : (
          <>All checks passed: complete actuals, multiple forecast publications, half-hourly resolution.</>
        )}
      </div>

      <div className="grid">
        <Kpi label="Data source" value={live ? "Live Elexon" : "Synthetic"} sub={`${data.source}${data.fetchedAt ? ` · fetched ${londonTime(data.fetchedAt)}` : ""}`} highlight={live} />
        <Kpi label="Actual records" value={a.count.toLocaleString()} sub={`Expected ${a.expected.toLocaleString()} · missing ${a.missing}`} />
        <Kpi label="Forecast records" value={f.rows.toLocaleString()} sub={`${f.distinctPublishTimes} distinct publications`} />
        <Kpi label="Publications per day" value={f.publishesPerDay ?? "–"} sub={`Latest ${londonTime(f.lastPublish)}`} />
        <Kpi label="Forecast resolution" value={f.resolutionMinutes ? `${f.resolutionMinutes} min` : "–"} sub="Spacing of forecast target times" />
        <Kpi label="Delivery coverage" value={`${f.deliveryTargetsCovered.toLocaleString()} / ${f.deliveryTargetsExpected.toLocaleString()}`} sub="Half-hours with at least one forecast" />
      </div>

      <div className="card">
        <h3>How to read this</h3>
        <p className="desc">
          Actuals cover 1 Jan – 1 Feb (32 days × 48 = 1,536 half-hours); accuracy is evaluated on the 31 delivery days 2 Jan – 1 Feb
          ({q.expectedEvaluatedPeriods.toLocaleString()} half-hours). Forecast history is kept as separate publications so the desk's
          decision-time view never uses a forecast published after the cut-off. Half-hours without a forecast are excluded from the metrics, never filled in.
          First publication {londonTime(f.firstPublish)}.
        </p>
      </div>
    </>
  );
}
