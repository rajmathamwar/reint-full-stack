export default function Kpi({ label, value, sub, highlight }) {
  return (
    <div className={`kpi${highlight ? " hl" : ""}`}>
      <div className="label">{label}</div>
      <div className="value">{value}</div>
      {sub && <div className="sub">{sub}</div>}
    </div>
  );
}
