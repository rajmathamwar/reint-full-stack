import { useEffect, useMemo, useState } from "react";
import { ComposedChart, Area, Line, XAxis, YAxis, Tooltip, Legend, CartesianGrid, ResponsiveContainer } from "recharts";
import { api } from "../api.js";
import Kpi from "./Kpi.jsx";
import { mw, gw, signed, longDate, londonTime, downloadCsv } from "../format.js";

function dateOptions(win) {
  const out = [];
  for (let d = new Date(win.start + "T00:00:00Z"); d <= new Date(win.end + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + 1)) {
    out.push(d.toISOString().slice(0, 10));
  }
  return out;
}

export default function DecisionView({ meta, cutoff }) {
  const dates = useMemo(() => dateOptions(meta.decisionWindow), [meta]);
  const [date, setDate] = useState(dates[14]);
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [showActual, setShowActual] = useState(true);

  useEffect(() => {
    setData(null); setError(null);
    api.decision(date, cutoff).then(setData).catch((e) => setError(e.message));
  }, [date, cutoff]);

  const chartData = useMemo(
    () => (data ? data.rows.map((r) => ({ ...r, band: r.low != null ? [r.low, r.high] : null })) : []),
    [data]
  );

  return (
    <>
      <div className="controls">
        <label>
          Decision date (purchase made)
          <select value={date} onChange={(e) => setDate(e.target.value)}>
            {dates.map((d) => <option key={d} value={d}>{longDate(d)}</option>)}
          </select>
        </label>
        <label>
          Compare with outturn
          <select value={showActual ? "y" : "n"} onChange={(e) => setShowActual(e.target.value === "y")}>
            <option value="y">Show actual (hindsight)</option>
            <option value="n">Hide (decision-time view)</option>
          </select>
        </label>
        {data && <button onClick={() => downloadCsv(`wind-forecast-${data.deliveryDate}.csv`, data.rows.map(({ startTime, localTime, forecast, publishTime, horizonHours, actual, error, low, high }) => ({ startTime, localTime, forecast, publishTime, horizonHours, actual, error, p10: low, p90: high })))}>Export CSV</button>}
      </div>

      {error && <div className="error">{error}</div>}
      {!data && !error && <div className="loading">Loading forecast…</div>}
      {data && (
        <>
          <div className="insight">
            At <strong>{String(data.cutoff.hour).padStart(2, "0")}:{String(data.cutoff.minute).padStart(2, "0")} on {longDate(data.decisionDate)}</strong>,
            the latest wind forecast for <strong>{longDate(data.deliveryDate)}</strong> averaged <strong>{gw(data.summary.forecastMeanMw)}</strong>
            {data.uncertaintyBand
              ? <>; learning from the {data.uncertaintyBand.historyDays} earlier January decisions, you can count on about <strong>{gw(data.summary.reliableMeanMw)}</strong> with ~90% confidence.</>
              : <>. Not enough earlier decisions yet to quantify the uncertainty band.</>}
            {data.summary.missingForecastPeriods > 0 && <> {data.summary.missingForecastPeriods} half-hours had no forecast published by the cut-off.</>}
          </div>

          <div className="grid">
            <Kpi label="Mean forecast" value={gw(data.summary.forecastMeanMw)} sub={`Peak ${gw(data.summary.forecastPeakMw)} · Min ${gw(data.summary.forecastMinMw)}`} highlight />
            <Kpi label="Forecast energy" value={data.summary.forecastEnergyMwh != null ? `${(data.summary.forecastEnergyMwh / 1000).toFixed(0)} GWh` : "–"} sub="Over the delivery day" />
            <Kpi label="P90-safe wind (mean)" value={gw(data.summary.reliableMeanMw)} sub={data.uncertaintyBand ? `From ${data.uncertaintyBand.historyDays} prior days, no look-ahead` : "Needs ≥3 prior days"} />
            <Kpi label="Forecasts used" value={data.forecastPublishTimes.distinct ? `${data.forecastPublishTimes.distinct}` : "–"} sub={`Latest published ${londonTime(data.forecastPublishTimes.last)}`} />
          </div>

          <div className="card">
            <h3>Wind forecast available at the cut-off vs outturn</h3>
            <p className="desc">Solid line: what you could see when deciding. Shaded: 80% range learned from earlier days. Dashed: what actually happened (known only afterwards).</p>
            <ResponsiveContainer width="100%" height={380}>
              <ComposedChart data={chartData} margin={{ top: 8, right: 16, left: 8, bottom: 0 }}>
                <CartesianGrid stroke="#e3e8ef" strokeDasharray="3 3" />
                <XAxis dataKey="localTime" interval={3} tick={{ fontSize: 12 }} />
                <YAxis tickFormatter={(v) => `${(v / 1000).toFixed(0)}`} label={{ value: "GW", angle: -90, position: "insideLeft" }} tick={{ fontSize: 12 }} />
                <Tooltip formatter={(v, n) => (Array.isArray(v) ? `${mw(v[0])} – ${mw(v[1])}` : mw(v))} labelFormatter={(l) => `${l} (UK time)`} />
                <Legend />
                <Area dataKey="band" name="80% range" stroke="none" fill="#0f9d94" fillOpacity={0.15} isAnimationActive={false} />
                <Line dataKey="forecast" name="Forecast at cut-off" stroke="#0f9d94" strokeWidth={2.5} dot={false} isAnimationActive={false} />
                {showActual && <Line dataKey="actual" name="Actual outturn" stroke="#7b8794" strokeWidth={2} strokeDasharray="5 4" dot={false} isAnimationActive={false} />}
              </ComposedChart>
            </ResponsiveContainer>
          </div>

          {showActual && data.realised && (
            <div className="grid">
              <Kpi label="Realised MAE" value={mw(data.realised.mae)} sub="Mean absolute error that day" />
              <Kpi label="Realised bias" value={signed(data.realised.bias)} sub={data.realised.bias > 0 ? "Over-forecast (shortfall)" : "Under-forecast (surplus)"} />
              <Kpi label="Worst shortfall" value={signed(data.realised.p90Shortfall)} sub="90th percentile of error" />
            </div>
          )}

          <div className="card">
            <h3>Half-hourly detail</h3>
            <div className="scroll">
              <table>
                <thead><tr><th>Time (UK)</th><th>Forecast</th><th>Published</th><th>Lead</th>{showActual && <><th>Actual</th><th>Error</th></>}<th>P10–P90 wind</th></tr></thead>
                <tbody>
                  {data.rows.map((r) => (
                    <tr key={r.startTime}>
                      <td>{r.localTime}</td><td>{mw(r.forecast)}</td><td>{londonTime(r.publishTime)}</td>
                      <td>{r.horizonHours != null ? `${r.horizonHours.toFixed(1)}h` : "–"}</td>
                      {showActual && <><td>{mw(r.actual)}</td><td className={r.error > 0 ? "pos" : "neg"}>{signed(r.error)}</td></>}
                      <td>{r.low != null ? `${mw(r.low)} – ${mw(r.high)}` : "–"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </>
  );
}
