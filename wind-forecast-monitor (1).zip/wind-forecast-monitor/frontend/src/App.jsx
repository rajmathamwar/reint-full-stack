import { useEffect, useState } from "react";
import { api } from "./api.js";
import DecisionView from "./components/DecisionView.jsx";
import AccuracyView from "./components/AccuracyView.jsx";
import DataStatus from "./components/DataStatus.jsx";

export default function App() {
  const [tab, setTab] = useState("decision");
  const [meta, setMeta] = useState(null);
  const [error, setError] = useState(null);
  const [cutoff, setCutoff] = useState(null);

  useEffect(() => {
    api.meta().then((m) => { setMeta(m); setCutoff(m.defaultCutoff); }).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="error">Could not reach the API: {error}</div>;
  if (!meta || !cutoff) return <div className="loading">Loading…</div>;

  const synthetic = meta.data.synthetic;
  return (
    <>
      <header className="top">
        <div>
          <h1>Wind Forecast Monitor</h1>
          <p>Day-ahead procurement desk · GB national wind · Elexon FUELHH &amp; WINDFOR</p>
        </div>
        <nav className="tabs">
          <button className={tab === "decision" ? "active" : ""} onClick={() => setTab("decision")}>Decision view</button>
          <button className={tab === "accuracy" ? "active" : ""} onClick={() => setTab("accuracy")}>Forecast accuracy</button>
          <button className={tab === "status" ? "active" : ""} onClick={() => setTab("status")}>Data status</button>
        </nav>
      </header>
      <main>
        {synthetic && (
          <div className="banner warn">
            <strong>Synthetic demo data.</strong> These numbers are generated, not Elexon data
            {meta.data.note ? ` (${meta.data.note})` : ""}. Run the data refresh to load real January 2026 data.
          </div>
        )}
        <div className="controls">
          <label>
            Decision cut-off (UK time, day before delivery)
            <select
              value={cutoff.hour}
              onChange={(e) => setCutoff({ hour: Number(e.target.value), minute: 0 })}
            >
              {[...Array(24).keys()].map((h) => (
                <option key={h} value={h}>{String(h).padStart(2, "0")}:00</option>
              ))}
            </select>
          </label>
        </div>
        {tab === "decision" && <DecisionView meta={meta} cutoff={cutoff} />}
        {tab === "accuracy" && <AccuracyView cutoff={cutoff} />}
        {tab === "status" && <DataStatus />}
      </main>
      <footer>
        Contains BMRS data © Elexon Limited. Error = forecast − actual; positive = over-forecast (wind shortfall).
        {meta.data.fetchedAt ? ` Data snapshot: ${meta.data.fetchedAt}.` : ""}
      </footer>
    </>
  );
}
