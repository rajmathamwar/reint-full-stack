# Video script (target 9:00, hard limit 10:00)

## Part 1 — Client pitch (≈4:30)
**0:00 Problem (30s).** "Every morning you commit to day-ahead volumes for tomorrow. Wind is your biggest swing factor, and you decide on a forecast. Two questions: what did the forecast say when you had to decide, and how far can you trust it?"
**0:30 Decision view (90s).** Pick a mid-January date. Show the forecast line, publish time and lead time of the data used, the shaded 80% range, and the P90-safe wind KPI. Toggle "hide actual" — this is exactly what you'd have seen. Toggle it back to reveal outturn. Change the cut-off hour and show the forecast change.
**2:00 Accuracy (90s).** Open the accuracy tab: headline MAE, bias, P90 shortfall in plain English (the insight banner). Show error by time of day, then lead time: "forecasts improve sharply closer to delivery — day-ahead is inherently the noisy end."
**3:30 Value (45s).** "Plan thermal cover against the P90-safe figure, not the raw forecast." Mention CSV export.
**4:15 Close (15s).** Next steps: add demand and price data, intraday updates, alerts.

## Part 2 — Technical review (≈4:30)
**0:00 Architecture (60s).** React/Vite UI → FastAPI → analysis module; data layer: snapshot → live Elexon → synthetic fallback. Single Docker image; Vercel serverless for the deployed app.
**1:00 The core rule (90s).** Open `analysis.py`: `Dataset.latest_forecast` (bisect on publish time ≤ cut-off), `decision_rows`, sign convention, `reliability_band` (no look-ahead). Explain why wMAPE and the 500 MW MAPE floor.
**2:30 Data layer (45s).** `elexon.py`: chunked windows, revision handling (latest publishTime wins), defensive fuelType fallback. `refresh.py` + committed snapshot for determinism.
**3:15 Quality (60s).** Run pytest: hand-computed metrics, cut-off inclusivity, BST handling, look-ahead test, API tests. CI workflow. Synthetic data is labelled in API and UI.
**4:15 Trade-offs (15s).** Pure Python over pandas (small data, light serverless bundle); assumed 09:00 cut-off; wind-only scope.
