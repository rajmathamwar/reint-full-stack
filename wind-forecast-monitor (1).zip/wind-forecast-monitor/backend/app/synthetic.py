"""Deterministic SYNTHETIC wind data for tests and offline demos only.

It is never mixed with real data and the API/UI label it loudly as synthetic.
"""
from __future__ import annotations

import math
import random
from datetime import datetime, timedelta, timezone

UTC = timezone.utc
HALF_HOUR = timedelta(minutes=30)


def generate(start: datetime, end: datetime, publish_every_hours: int = 3, seed: int = 42):
    """Return (actuals, forecasts). Forecast error grows with lead time and has a small positive bias."""
    rng = random.Random(seed)
    actuals: dict[datetime, float] = {}
    level, t = 8000.0, start
    while t < end:
        level += rng.gauss(0, 220) + (8000 - level) * 0.02  # mean-reverting random walk
        level = min(max(level, 300.0), 20000.0)
        actuals[t] = level
        t += HALF_HOUR

    forecasts: list[tuple[datetime, datetime, float]] = []
    pub = start - timedelta(days=2)
    while pub < end:
        for k in range(0, 96):  # 48h of half-hour targets
            tgt = pub + timedelta(minutes=30 * k)
            if tgt in actuals:
                horizon_h = k / 2
                sigma = 250 + 55 * horizon_h
                noise = rng.gauss(150, sigma)  # +150 MW bias -> mild over-forecast
                forecasts.append((pub, tgt, max(0.0, actuals[tgt] + noise)))
        pub += timedelta(hours=publish_every_hours)
    return actuals, forecasts
