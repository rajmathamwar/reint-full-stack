"""Thin, defensive client for the Elexon Insights (BMRS) open API. No API key is required."""
from __future__ import annotations

import logging
import time
from datetime import date, datetime, timedelta, timezone
from typing import Iterable

import httpx

from .config import ELEXON_BASE_URL

log = logging.getLogger(__name__)
UTC = timezone.utc
RETRY_STATUS = {429, 500, 502, 503, 504}
_sleep = time.sleep  # replaced in tests so retries are instant


def parse_ts(value: str) -> datetime:
    """Parse Elexon ISO timestamps (e.g. 2026-01-01T00:30:00Z) into aware UTC datetimes."""
    return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)


def _rows(payload) -> list[dict]:
    """Stream endpoints return a bare JSON array; some return {'data': [...]}. Accept both."""
    if isinstance(payload, dict):
        return payload.get("data", [])
    return payload


def _get(client: httpx.Client, path: str, params: dict, attempts: int = 3) -> list[dict]:
    """GET with retries on timeouts, connection errors and 429/5xx (exponential backoff).
    4xx errors other than 429 are raised immediately (they indicate a bad request, not a flaky API)."""
    for i in range(attempts):
        last = i == attempts - 1
        try:
            resp = client.get(f"{ELEXON_BASE_URL}{path}", params=params, timeout=60)
        except (httpx.TimeoutException, httpx.TransportError) as exc:
            if last:
                raise
            log.warning("%s failed (%s); retry %d/%d", path, exc, i + 1, attempts - 1)
            _sleep(2**i)
            continue
        if resp.status_code in RETRY_STATUS and not last:
            log.warning("%s -> HTTP %s; retry %d/%d", path, resp.status_code, i + 1, attempts - 1)
            _sleep(2**i)
            continue
        resp.raise_for_status()
        return _rows(resp.json())
    return []  # unreachable


def _chunks(start: date, end: date, days: int) -> Iterable[tuple[date, date]]:
    cur = start
    while cur <= end:
        nxt = min(cur + timedelta(days=days - 1), end)
        yield cur, nxt
        cur = nxt + timedelta(days=1)


def fetch_actuals(client: httpx.Client, start: date, end: date) -> dict[datetime, float]:
    """FUELHH wind outturn, keyed by startTime (UTC). Latest publishTime wins on revisions."""
    best: dict[datetime, tuple[datetime, float]] = {}
    for a, b in _chunks(start, end, 7):
        params = {"settlementDateFrom": a.isoformat(), "settlementDateTo": b.isoformat(), "fuelType": "WIND"}
        try:
            rows = _get(client, "/datasets/FUELHH/stream", params)
        except httpx.HTTPStatusError:
            # Some API versions reject the fuelType filter; fall back to client-side filtering.
            params.pop("fuelType")
            rows = _get(client, "/datasets/FUELHH/stream", params)
        for r in rows:
            if r.get("fuelType") != "WIND" or r.get("generation") is None:
                continue
            start_t = parse_ts(r["startTime"])
            pub = parse_ts(r["publishTime"]) if r.get("publishTime") else start_t
            if start_t not in best or pub >= best[start_t][0]:
                best[start_t] = (pub, float(r["generation"]))
    return {t: v for t, (_, v) in best.items()}


def fetch_forecasts(client: httpx.Client, publish_from: datetime, publish_to: datetime) -> list[tuple[datetime, datetime, float]]:
    """WINDFOR rows as (publishTime, startTime, generation). Fetched in 3-day publish windows."""
    out: dict[tuple[datetime, datetime], float] = {}
    cur = publish_from
    while cur < publish_to:
        nxt = min(cur + timedelta(days=3), publish_to)
        rows = _get(
            client,
            "/datasets/WINDFOR/stream",
            {
                "publishDateTimeFrom": cur.strftime("%Y-%m-%dT%H:%M:%SZ"),
                "publishDateTimeTo": nxt.strftime("%Y-%m-%dT%H:%M:%SZ"),
            },
        )
        for r in rows:
            if r.get("generation") is None:
                continue
            out[(parse_ts(r["publishTime"]), parse_ts(r["startTime"]))] = float(r["generation"])
        cur = nxt
    return [(p, s, g) for (p, s), g in sorted(out.items())]
