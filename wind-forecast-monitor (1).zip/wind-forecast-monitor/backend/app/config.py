"""Central configuration. Everything tunable lives here or in environment variables."""
from __future__ import annotations

import os
from datetime import date
from pathlib import Path

ELEXON_BASE_URL = "https://data.elexon.co.uk/bmrs/api/v1"

# Scope of the pilot: purchase decisions taken in January 2026.
DECISION_WINDOW_START = date(2026, 1, 1)
DECISION_WINDOW_END = date(2026, 1, 31)

# Day-ahead purchase decision cut-off, expressed in UK local time on the day
# BEFORE delivery. The auction gate closes later than this; 09:00 leaves the
# trading desk time to act. Overridable per request in the UI/API.
DEFAULT_CUTOFF_HOUR = int(os.getenv("DECISION_CUTOFF_HOUR", "9"))
DEFAULT_CUTOFF_MINUTE = int(os.getenv("DECISION_CUTOFF_MINUTE", "0"))

DATA_DIR = Path(os.getenv("DATA_DIR", Path(__file__).resolve().parent.parent / "data"))
SNAPSHOT_PATH = DATA_DIR / "snapshot.json"

# If no snapshot is present: "live" fetches from Elexon on first use,
# "synthetic" generates clearly-labelled demo data (never presented as real).
FALLBACK_MODE = os.getenv("FALLBACK_MODE", "live")

# Minimum number of prior delivery days before an uncertainty band is shown.
MIN_HISTORY_DAYS = 3
# Actuals below this (MW) are excluded from percentage errors to avoid blow-ups.
MAPE_MIN_ACTUAL_MW = 500.0
