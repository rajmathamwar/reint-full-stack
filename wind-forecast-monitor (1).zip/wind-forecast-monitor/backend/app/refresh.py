"""Download the January 2026 pilot data from Elexon and write backend/data/snapshot.json.

    python -m app.refresh        (run from the backend/ directory, needs internet access)

Safety rules: an empty or failed download NEVER overwrites an existing snapshot (exit code 1).
Warnings (single publishTime, hourly resolution, missing periods) are printed but do not block the write,
so you can inspect the data; read them before trusting the numbers.
"""
import logging
import sys

from .config import DECISION_WINDOW_END, DECISION_WINDOW_START
from .quality import quality_report
from .store import SNAPSHOT_PATH, fetch_live, save_snapshot

logging.basicConfig(level=logging.INFO)


def main() -> int:
    try:
        ds = fetch_live()
    except Exception as exc:
        print(f"ERROR: live fetch failed: {exc}\nExisting snapshot (if any) left untouched.", file=sys.stderr)
        return 1
    if not ds.actuals or not ds.forecasts:
        print(f"ERROR: Elexon returned {len(ds.actuals)} actuals and {len(ds.forecasts)} forecasts; refusing to write an "
              "empty snapshot. Existing snapshot (if any) left untouched.", file=sys.stderr)
        return 1

    q = quality_report(ds, DECISION_WINDOW_START, DECISION_WINDOW_END)
    save_snapshot(ds)
    a, f = q["actuals"], q["forecasts"]
    print(f"Wrote {SNAPSHOT_PATH}")
    print(f"  actuals   : {a['count']} (expected ~{a['expected']}, missing {a['missing']})")
    print(f"  forecasts : {f['rows']} rows, {f['distinctPublishTimes']} distinct publishTimes "
          f"({f['firstPublish']} -> {f['lastPublish']}), ~{f['publishesPerDay']}/day")
    print(f"  resolution: {f['resolutionMinutes']} min; delivery half-hours with a forecast: "
          f"{f['deliveryTargetsCovered']}/{f['deliveryTargetsExpected']}")
    for w in q["warnings"]:
        print(f"  WARNING: {w}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
