"""Pure analysis logic: no I/O, no framework imports, fully unit-testable.

Sign convention (used everywhere):  error = forecast - actual   (MW)
  error > 0  -> OVER-forecast : less wind arrived than planned -> shortfall the desk must cover
  error < 0  -> UNDER-forecast: more wind than planned          -> surplus / over-procurement
"""
from __future__ import annotations

import math
from bisect import bisect_right
from dataclasses import dataclass, field
from datetime import date, datetime, time, timedelta, timezone
from statistics import mean
from zoneinfo import ZoneInfo

from .config import MAPE_MIN_ACTUAL_MW, MIN_HISTORY_DAYS

UTC = timezone.utc
LONDON = ZoneInfo("Europe/London")
HALF_HOUR = timedelta(minutes=30)


# ----------------------------------------------------------------------------- dataset
@dataclass
class Dataset:
    actuals: dict[datetime, float]
    forecasts: list[tuple[datetime, datetime, float]]  # (publishTime, startTime, MW)
    meta: dict = field(default_factory=dict)
    _by_target: dict[datetime, list[tuple[datetime, float]]] = field(default_factory=dict, repr=False)

    def __post_init__(self) -> None:
        by_target: dict[datetime, list[tuple[datetime, float]]] = {}
        for pub, start, mw in self.forecasts:
            by_target.setdefault(start, []).append((pub, mw))
        for lst in by_target.values():
            lst.sort(key=lambda x: x[0])
        self._by_target = by_target

    def latest_forecast(self, target: datetime, cutoff: datetime) -> tuple[datetime, float] | None:
        """Most recent forecast for `target` that was published at or before `cutoff`."""
        lst = self._by_target.get(target)
        if not lst:
            return None
        idx = bisect_right([p for p, _ in lst], cutoff)
        return lst[idx - 1] if idx else None


# ----------------------------------------------------------------------------- time helpers
def cutoff_utc(decision_date: date, hour: int, minute: int) -> datetime:
    """Decision cut-off: `hour:minute` UK local time on the decision date (= delivery day - 1)."""
    return datetime.combine(decision_date, time(hour, minute), tzinfo=LONDON).astimezone(UTC)


def delivery_targets(delivery_date: date) -> list[datetime]:
    """All half-hour start times (UTC) inside the UK-local delivery day."""
    start = datetime.combine(delivery_date, time(0), tzinfo=LONDON).astimezone(UTC)
    end = datetime.combine(delivery_date + timedelta(days=1), time(0), tzinfo=LONDON).astimezone(UTC)
    out, t = [], start
    while t < end:
        out.append(t)
        t += HALF_HOUR
    return out


def iso(dt: datetime) -> str:
    return dt.astimezone(UTC).strftime("%Y-%m-%dT%H:%M:%SZ")


# ----------------------------------------------------------------------------- decision view
def decision_rows(ds: Dataset, decision_date: date, hour: int, minute: int) -> list[dict]:
    """Forecast available at the cut-off, for every half-hour of the following delivery day."""
    cutoff = cutoff_utc(decision_date, hour, minute)
    rows = []
    for t in delivery_targets(decision_date + timedelta(days=1)):
        fc = ds.latest_forecast(t, cutoff)
        actual = ds.actuals.get(t)
        pub, mw = fc if fc else (None, None)
        err = (mw - actual) if (mw is not None and actual is not None) else None
        rows.append(
            {
                "startTime": iso(t),
                "localTime": t.astimezone(LONDON).strftime("%H:%M"),
                "forecast": mw,
                "publishTime": iso(pub) if pub else None,
                "horizonHours": round((t - pub).total_seconds() / 3600, 2) if pub else None,
                "actual": actual,
                "error": err,
            }
        )
    return rows


# ----------------------------------------------------------------------------- statistics
def quantile(values: list[float], q: float) -> float | None:
    """Linear-interpolated quantile (same as numpy default)."""
    if not values:
        return None
    s = sorted(values)
    pos = (len(s) - 1) * q
    lo, hi = math.floor(pos), math.ceil(pos)
    return s[lo] + (s[hi] - s[lo]) * (pos - lo)


def metrics(errors: list[float], actuals: list[float]) -> dict:
    """Accuracy summary for paired (error, actual) lists."""
    n = len(errors)
    if n == 0:
        return {"n": 0}
    abs_e = [abs(e) for e in errors]
    pct = [abs(e) / a for e, a in zip(errors, actuals) if a >= MAPE_MIN_ACTUAL_MW]
    total_actual = sum(actuals)
    return {
        "n": n,
        "mae": mean(abs_e),
        "rmse": math.sqrt(mean(e * e for e in errors)),
        "bias": mean(errors),
        "mape": mean(pct) * 100 if pct else None,
        "wmape": (sum(abs_e) / total_actual * 100) if total_actual > 0 else None,
        "meanActual": mean(actuals),
        "p50AbsError": quantile(abs_e, 0.5),
        "p90AbsError": quantile(abs_e, 0.9),
        "p95AbsError": quantile(abs_e, 0.95),
        # Tails of the signed error: what the desk actually needs for risk planning.
        "p90Shortfall": quantile(errors, 0.9),  # wind arrives this far BELOW forecast, 1 time in 10
        "p10Surplus": quantile(errors, 0.1),  # wind arrives this far ABOVE forecast, 1 time in 10 (negative)
    }


def _paired(rows: list[dict]) -> tuple[list[float], list[float]]:
    pairs = [(r["error"], r["actual"]) for r in rows if r["error"] is not None]
    return [e for e, _ in pairs], [a for _, a in pairs]


def reliability_band(ds: Dataset, decision_date: date, hour: int, minute: int, window_start: date) -> dict | None:
    """Uncertainty band for a decision, learned ONLY from earlier decisions (no look-ahead).

    Returns the signed-error quantiles pooled over prior delivery days, or None if there is
    too little history.
    """
    errors: list[float] = []
    days = 0
    d = window_start
    while d < decision_date:
        e, _ = _paired(decision_rows(ds, d, hour, minute))
        if e:
            errors.extend(e)
            days += 1
        d += timedelta(days=1)
    if days < MIN_HISTORY_DAYS:
        return None
    return {
        "historyDays": days,
        "q10": quantile(errors, 0.10),
        "q50": quantile(errors, 0.50),
        "q90": quantile(errors, 0.90),
    }


def apply_band(rows: list[dict], band: dict | None) -> None:
    """Annotate rows with an 80% interval and a P90-safe 'reliable wind' figure (in place)."""
    for r in rows:
        f = r["forecast"]
        if band is None or f is None:
            r["low"] = r["high"] = r["reliable"] = None
            continue
        # actual = forecast - error  ->  actual quantiles are forecast minus error quantiles (reversed)
        r["low"] = max(0.0, f - band["q90"])  # 10th percentile of actual
        r["high"] = max(0.0, f - band["q10"])  # 90th percentile of actual
        r["reliable"] = r["low"]  # wind we can count on with ~90% confidence


# ----------------------------------------------------------------------------- accuracy suite
def decision_dates(start: date, end: date) -> list[date]:
    return [start + timedelta(days=i) for i in range((end - start).days + 1)]


def accuracy(ds: Dataset, start: date, end: date, hour: int, minute: int) -> dict:
    all_rows: list[dict] = []
    per_day = []
    for d in decision_dates(start, end):
        rows = decision_rows(ds, d, hour, minute)
        e, a = _paired(rows)
        m = metrics(e, a)
        per_day.append({"decisionDate": d.isoformat(), "deliveryDate": (d + timedelta(days=1)).isoformat(), **m})
        all_rows.extend(rows)

    errors, actuals = _paired(all_rows)
    overall = metrics(errors, actuals)

    # Error profile by half-hour of the delivery day (local time)
    buckets: dict[str, list[tuple[float, float]]] = {}
    for r in all_rows:
        if r["error"] is not None:
            buckets.setdefault(r["localTime"], []).append((r["error"], r["actual"]))
    by_time = []
    for lt in sorted(buckets):
        e = [x for x, _ in buckets[lt]]
        by_time.append(
            {
                "localTime": lt,
                "n": len(e),
                "mae": mean(abs(x) for x in e),
                "bias": mean(e),
                "p10": quantile(e, 0.1),
                "p90": quantile(e, 0.9),
            }
        )

    # Histogram of signed errors, 1 GW bins, tails clipped into the end bins
    width, lo_edge, hi_edge = 1000, -6000, 6000
    edges = list(range(lo_edge, hi_edge + width, width))
    counts = [0] * (len(edges) - 1)
    for e in errors:
        idx = min(max(int((e - lo_edge) // width), 0), len(counts) - 1)
        counts[idx] += 1
    histogram = [{"from": edges[i], "to": edges[i + 1], "count": counts[i]} for i in range(len(counts))]

    return {
        "cutoff": {"hour": hour, "minute": minute, "timezone": "Europe/London"},
        "coverage": {
            "targets": len(all_rows),
            "withForecast": sum(1 for r in all_rows if r["forecast"] is not None),
            "withActual": sum(1 for r in all_rows if r["actual"] is not None),
            "evaluated": len(errors),
        },
        "overall": overall,
        "perDay": per_day,
        "byTimeOfDay": by_time,
        "histogram": histogram,
    }


def horizon_analysis(ds: Dataset, start: date, end: date, bucket_hours: int = 6, max_hours: int = 48) -> list[dict]:
    """Accuracy as a function of forecast lead time, across EVERY published forecast (not just the
    decision-time one). Shows how much error shrinks as delivery approaches."""
    lo = datetime.combine(start + timedelta(days=1), time(0), tzinfo=LONDON).astimezone(UTC)
    hi = datetime.combine(end + timedelta(days=2), time(0), tzinfo=LONDON).astimezone(UTC)
    nb = max_hours // bucket_hours + 1
    acc: list[list[tuple[float, float]]] = [[] for _ in range(nb)]
    for pub, tgt, mw in ds.forecasts:
        if not (lo <= tgt < hi):
            continue
        actual = ds.actuals.get(tgt)
        if actual is None:
            continue
        h = (tgt - pub).total_seconds() / 3600
        if h < 0:
            continue
        acc[min(int(h // bucket_hours), nb - 1)].append((mw - actual, actual))
    out = []
    for i, pairs in enumerate(acc):
        if not pairs:
            continue
        label = f"{i * bucket_hours}-{(i + 1) * bucket_hours}h" if i < nb - 1 else f"{i * bucket_hours}h+"
        m = metrics([e for e, _ in pairs], [a for _, a in pairs])
        out.append({"bucket": label, "fromHours": i * bucket_hours, **m})
    return out
