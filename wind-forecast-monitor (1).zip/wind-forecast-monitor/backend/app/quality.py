"""Data-quality report: answers "is the data I loaded actually what I expect?" (pure, no I/O)."""
from __future__ import annotations

from collections import Counter
from datetime import date, datetime, time, timedelta, timezone

from .analysis import HALF_HOUR, LONDON, Dataset, delivery_targets, iso

UTC = timezone.utc


def _day_targets(first: date, last: date) -> list[datetime]:
    out, d = [], first
    while d <= last:
        out.extend(delivery_targets(d))
        d += timedelta(days=1)
    return out


def forecast_resolution_minutes(ds: Dataset) -> int | None:
    """Spacing of target times inside the most populated publication (60 => hourly, 30 => half-hourly)."""
    if not ds.forecasts:
        return None
    counts = Counter(p for p, _, _ in ds.forecasts)
    pub = counts.most_common(1)[0][0]
    targets = sorted(s for p, s, _ in ds.forecasts if p == pub)
    gaps = Counter(int((b - a).total_seconds() // 60) for a, b in zip(targets, targets[1:]))
    return gaps.most_common(1)[0][0] if gaps else None


def quality_report(ds: Dataset, window_start: date, window_end: date) -> dict:
    # Actuals are fetched for window_start .. window_end + 1 day; evaluation covers delivery days start+1 .. end+1.
    actual_targets = _day_targets(window_start, window_end + timedelta(days=1))
    eval_targets = _day_targets(window_start + timedelta(days=1), window_end + timedelta(days=1))
    missing_actuals = sum(1 for t in actual_targets if t not in ds.actuals)
    covered = sum(1 for t in eval_targets if t in ds._by_target)
    pubs = sorted({p for p, _, _ in ds.forecasts})
    days = max(1, (window_end - window_start).days + 1)
    res = forecast_resolution_minutes(ds)

    warnings: list[str] = []
    if ds.meta.get("synthetic"):
        warnings.append("Data is SYNTHETIC demo data, not Elexon data.")
    if not ds.actuals:
        warnings.append("No actual generation records loaded.")
    if not ds.forecasts:
        warnings.append("No forecast records loaded.")
    if ds.forecasts and len(pubs) == 1:
        warnings.append("Every forecast has the same publishTime: forecast history was not retrieved.")
    if res is not None and res != 30:
        warnings.append(
            f"Forecast resolution is {res} minutes, not 30: half-hours between forecast points have no "
            "forecast and are excluded from evaluation (no interpolation)."
        )
    if missing_actuals:
        warnings.append(f"{missing_actuals} half-hour actuals are missing.")
    if eval_targets and covered < len(eval_targets):
        warnings.append(f"{len(eval_targets) - covered} of {len(eval_targets)} delivery half-hours have no forecast at all.")

    return {
        "actuals": {"count": len(ds.actuals), "expected": len(actual_targets), "missing": missing_actuals},
        "forecasts": {
            "rows": len(ds.forecasts),
            "distinctPublishTimes": len(pubs),
            "firstPublish": iso(pubs[0]) if pubs else None,
            "lastPublish": iso(pubs[-1]) if pubs else None,
            "publishesPerDay": round(len(pubs) / days, 2) if pubs else None,
            "resolutionMinutes": res,
            "deliveryTargetsCovered": covered,
            "deliveryTargetsExpected": len(eval_targets),
        },
        "expectedEvaluatedPeriods": len(eval_targets),
        "warnings": warnings,
    }
