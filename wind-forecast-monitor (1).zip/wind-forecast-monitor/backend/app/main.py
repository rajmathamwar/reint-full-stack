"""FastAPI application: JSON API under /api, and (in Docker) the built React app at /."""
from __future__ import annotations

from datetime import date, timedelta
from functools import lru_cache
from pathlib import Path

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import analysis, quality
from .config import (DECISION_WINDOW_END, DECISION_WINDOW_START, DEFAULT_CUTOFF_HOUR, DEFAULT_CUTOFF_MINUTE)
from .store import get_dataset

app = FastAPI(title="Wind Forecast Monitor API", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET"], allow_headers=["*"])

Hour = Query(DEFAULT_CUTOFF_HOUR, ge=0, le=23, description="Cut-off hour, UK local time, day before delivery")
Minute = Query(DEFAULT_CUTOFF_MINUTE, ge=0, le=59)


def _check_decision_date(d: date) -> None:
    if not (DECISION_WINDOW_START <= d <= DECISION_WINDOW_END):
        raise HTTPException(
            422, f"decision_date must be within {DECISION_WINDOW_START} .. {DECISION_WINDOW_END} (pilot scope)"
        )


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.get("/api/meta")
def meta():
    ds = get_dataset()
    return {
        "decisionWindow": {"start": DECISION_WINDOW_START.isoformat(), "end": DECISION_WINDOW_END.isoformat()},
        "defaultCutoff": {"hour": DEFAULT_CUTOFF_HOUR, "minute": DEFAULT_CUTOFF_MINUTE, "timezone": "Europe/London"},
        "data": ds.meta,
        # "forecastRows" kept for backwards compatibility; "forecasts" is the preferred key.
        "counts": {"actuals": len(ds.actuals), "forecasts": len(ds.forecasts), "forecastRows": len(ds.forecasts)},
        "signConvention": "error = forecast - actual; positive = over-forecast (wind shortfall)",
    }


@lru_cache(maxsize=1)
def _quality_cached(_dataset_id: int):
    return quality.quality_report(get_dataset(), DECISION_WINDOW_START, DECISION_WINDOW_END)


@app.get("/api/quality")
def data_quality():
    """Is the loaded data what we expect? Counts, publication history, resolution, warnings."""
    ds = get_dataset()
    return {"data": ds.meta, **_quality_cached(id(ds))}


@app.get("/api/decision/{decision_date}")
def decision(decision_date: date, cutoff_hour: int = Hour, cutoff_minute: int = Minute):
    """The wind forecast the desk had in hand at the cut-off, for the following delivery day."""
    _check_decision_date(decision_date)
    ds = get_dataset()
    rows = analysis.decision_rows(ds, decision_date, cutoff_hour, cutoff_minute)
    band = analysis.reliability_band(ds, decision_date, cutoff_hour, cutoff_minute, DECISION_WINDOW_START)
    analysis.apply_band(rows, band)
    errors = [r["error"] for r in rows if r["error"] is not None]
    actuals = [r["actual"] for r in rows if r["error"] is not None]
    pubs = sorted({r["publishTime"] for r in rows if r["publishTime"]})
    fcs = [r["forecast"] for r in rows if r["forecast"] is not None]
    return {
        "decisionDate": decision_date.isoformat(),
        "deliveryDate": (decision_date + timedelta(days=1)).isoformat(),
        "cutoffUtc": analysis.iso(analysis.cutoff_utc(decision_date, cutoff_hour, cutoff_minute)),
        "cutoff": {"hour": cutoff_hour, "minute": cutoff_minute, "timezone": "Europe/London"},
        "forecastPublishTimes": {"first": pubs[0] if pubs else None, "last": pubs[-1] if pubs else None, "distinct": len(pubs)},
        "summary": {
            "forecastMeanMw": sum(fcs) / len(fcs) if fcs else None,
            "forecastPeakMw": max(fcs) if fcs else None,
            "forecastMinMw": min(fcs) if fcs else None,
            "forecastEnergyMwh": sum(fcs) * 0.5 if fcs else None,
            "reliableMeanMw": (sum(r["reliable"] for r in rows if r["reliable"] is not None) / max(1, sum(1 for r in rows if r["reliable"] is not None))) if band else None,
            "missingForecastPeriods": sum(1 for r in rows if r["forecast"] is None),
        },
        "uncertaintyBand": band,
        "realised": analysis.metrics(errors, actuals) if errors else None,
        "rows": rows,
    }


@lru_cache(maxsize=64)
def _accuracy_cached(hour: int, minute: int):
    return analysis.accuracy(get_dataset(), DECISION_WINDOW_START, DECISION_WINDOW_END, hour, minute)


@app.get("/api/accuracy")
def accuracy(cutoff_hour: int = Hour, cutoff_minute: int = Minute):
    """Quantitative accuracy of the decision-time forecast across all January decisions."""
    return _accuracy_cached(cutoff_hour, cutoff_minute)


@app.get("/api/horizon")
def horizon():
    """Accuracy versus forecast lead time, across every published forecast."""
    return {"buckets": analysis.horizon_analysis(get_dataset(), DECISION_WINDOW_START, DECISION_WINDOW_END)}


# ---- Serve the built React app when present (Docker image). On Vercel static files are served by the platform.
_dist = Path(__file__).resolve().parent.parent / "static"
if _dist.exists():
    app.mount("/assets", StaticFiles(directory=_dist / "assets"), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(404)
        candidate = _dist / full_path
        return FileResponse(candidate if candidate.is_file() else _dist / "index.html")
