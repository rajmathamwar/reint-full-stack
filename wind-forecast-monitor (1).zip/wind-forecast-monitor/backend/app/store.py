"""Data access: snapshot file -> live Elexon fetch -> synthetic fallback. Loaded once per process."""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, time, timedelta, timezone

import httpx

from . import elexon, synthetic
from .analysis import LONDON, Dataset, iso
from .config import (DECISION_WINDOW_END, DECISION_WINDOW_START, FALLBACK_MODE, SNAPSHOT_PATH)

log = logging.getLogger(__name__)
UTC = timezone.utc
_lock = threading.Lock()
_dataset: Dataset | None = None


def window_bounds() -> tuple[datetime, datetime]:
    """UTC bounds covering all forecasts published and all outturns needed for the pilot window."""
    start = datetime.combine(DECISION_WINDOW_START, time(0), tzinfo=LONDON).astimezone(UTC)
    end = datetime.combine(DECISION_WINDOW_END + timedelta(days=2), time(0), tzinfo=LONDON).astimezone(UTC)
    return start, end


def fetch_live() -> Dataset:
    start, end = window_bounds()
    with httpx.Client() as client:
        actuals = elexon.fetch_actuals(client, DECISION_WINDOW_START, DECISION_WINDOW_END + timedelta(days=1))
        # Forecasts published up to the end of the last decision day are all that matter for decisions;
        # later publications are kept for the lead-time analysis.
        forecasts = elexon.fetch_forecasts(client, start - timedelta(days=1), end)
    return Dataset(
        actuals,
        forecasts,
        meta={"source": "elexon-live", "fetchedAt": iso(datetime.now(UTC)), "synthetic": False},
    )


def save_snapshot(ds: Dataset) -> None:
    SNAPSHOT_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "meta": ds.meta,
        "actuals": [[iso(t), v] for t, v in sorted(ds.actuals.items())],
        "forecasts": [[iso(p), iso(s), g] for p, s, g in ds.forecasts],
    }
    SNAPSHOT_PATH.write_text(json.dumps(payload, separators=(",", ":")))


def load_snapshot() -> Dataset:
    raw = json.loads(SNAPSHOT_PATH.read_text())
    meta = {**raw["meta"], "source": raw["meta"].get("source", "snapshot")}
    return Dataset(
        {elexon.parse_ts(t): v for t, v in raw["actuals"]},
        [(elexon.parse_ts(p), elexon.parse_ts(s), g) for p, s, g in raw["forecasts"]],
        meta=meta,
    )


def synthetic_dataset() -> Dataset:
    start, end = window_bounds()
    actuals, forecasts = synthetic.generate(start, end)
    return Dataset(
        actuals,
        forecasts,
        meta={"source": "synthetic", "fetchedAt": iso(datetime.now(UTC)), "synthetic": True},
    )


def get_dataset() -> Dataset:
    global _dataset
    if _dataset is not None:
        return _dataset
    with _lock:
        if _dataset is not None:
            return _dataset
        if SNAPSHOT_PATH.exists():
            _dataset = load_snapshot()
            log.info("Loaded snapshot %s", SNAPSHOT_PATH)
        elif FALLBACK_MODE == "live":
            try:
                _dataset = fetch_live()
            except Exception as exc:  # network blocked, API down, ...
                log.error("Live fetch failed (%s); using synthetic demo data", exc)
                _dataset = synthetic_dataset()
                _dataset.meta["note"] = f"Live fetch failed: {exc}"
        else:
            _dataset = synthetic_dataset()
        return _dataset


def reset_dataset(ds: Dataset | None = None) -> None:
    """Test hook / refresh hook."""
    global _dataset
    _dataset = ds
