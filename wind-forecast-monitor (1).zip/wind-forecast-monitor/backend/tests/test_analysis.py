from datetime import date, datetime, timedelta, timezone

import pytest

from app import analysis
from app.analysis import Dataset

UTC = timezone.utc


def dt(day, h, m=0):
    return datetime(2026, 1, day, h, m, tzinfo=UTC)


def test_cutoff_is_previous_day_london_time():
    # January: London == UTC
    assert analysis.cutoff_utc(date(2026, 1, 14), 9, 0) == dt(14, 9)


def test_cutoff_respects_bst():
    # July: London = UTC+1, so 09:00 local is 08:00 UTC
    assert analysis.cutoff_utc(date(2026, 7, 1), 9, 0) == datetime(2026, 7, 1, 8, 0, tzinfo=UTC)


def test_delivery_day_has_48_periods_in_winter():
    t = analysis.delivery_targets(date(2026, 1, 15))
    assert len(t) == 48 and t[0] == dt(15, 0) and t[-1] == dt(15, 23, 30)


def test_latest_forecast_uses_only_forecasts_published_before_cutoff():
    target = dt(15, 12)
    ds = Dataset(
        actuals={target: 5000.0},
        forecasts=[
            (dt(13, 6), target, 4000.0),
            (dt(14, 8), target, 4500.0),   # latest before 09:00 cutoff
            (dt(14, 10), target, 9999.0),  # published AFTER cutoff -> must be ignored
        ],
    )
    pub, mw = ds.latest_forecast(target, dt(14, 9))
    assert (pub, mw) == (dt(14, 8), 4500.0)


def test_cutoff_is_inclusive():
    target = dt(15, 12)
    ds = Dataset({}, [(dt(14, 9), target, 1.0)])
    assert ds.latest_forecast(target, dt(14, 9)) is not None


def test_no_forecast_before_cutoff_returns_none():
    target = dt(15, 12)
    ds = Dataset({}, [(dt(14, 10), target, 1.0)])
    assert ds.latest_forecast(target, dt(14, 9)) is None


def test_decision_rows_sign_convention_and_horizon():
    target = dt(15, 12)
    ds = Dataset({target: 5000.0}, [(dt(14, 9), target, 5600.0)])
    row = next(r for r in analysis.decision_rows(ds, date(2026, 1, 14), 9, 0) if r["startTime"] == "2026-01-15T12:00:00Z")
    assert row["error"] == 600.0  # over-forecast -> positive
    assert row["horizonHours"] == 27.0
    assert row["localTime"] == "12:00"


def test_quantile_matches_linear_interpolation():
    assert analysis.quantile([1, 2, 3, 4], 0.5) == 2.5
    assert analysis.quantile([1, 2, 3, 4, 5], 0.9) == pytest.approx(4.6)
    assert analysis.quantile([], 0.5) is None


def test_metrics_hand_computed():
    m = analysis.metrics([100.0, -300.0], [1000.0, 2000.0])
    assert m["mae"] == 200.0
    assert m["bias"] == -100.0
    assert m["rmse"] == pytest.approx(((100**2 + 300**2) / 2) ** 0.5)
    assert m["mape"] == pytest.approx((0.1 + 0.15) / 2 * 100)
    assert m["wmape"] == pytest.approx(400 / 3000 * 100)


def test_mape_ignores_near_zero_actuals():
    m = analysis.metrics([10.0, 10.0], [0.0, 1000.0])
    assert m["mape"] == pytest.approx(1.0)


def test_reliability_band_has_no_lookahead_and_needs_history():
    # Every period over-forecast by exactly 500 MW on days 1..5
    actuals, forecasts = {}, []
    for d in range(1, 8):
        for t in analysis.delivery_targets(date(2026, 1, d + 1)):
            actuals[t] = 3000.0
            forecasts.append((analysis.cutoff_utc(date(2026, 1, d), 9, 0) - timedelta(hours=1), t, 3500.0))
    ds = Dataset(actuals, forecasts)
    start = date(2026, 1, 1)
    assert analysis.reliability_band(ds, date(2026, 1, 3), 9, 0, start) is None  # only 2 prior days
    band = analysis.reliability_band(ds, date(2026, 1, 6), 9, 0, start)
    assert band["historyDays"] == 5 and band["q50"] == 500.0
    rows = analysis.decision_rows(ds, date(2026, 1, 6), 9, 0)
    analysis.apply_band(rows, band)
    assert rows[0]["reliable"] == 3000.0  # 3500 - 500


def test_accuracy_and_horizon_end_to_end_with_perfect_forecast():
    actuals, forecasts = {}, []
    for t in analysis.delivery_targets(date(2026, 1, 2)):
        actuals[t] = 1000.0
        forecasts.append((dt(1, 9), t, 1000.0))
    ds = Dataset(actuals, forecasts)
    res = analysis.accuracy(ds, date(2026, 1, 1), date(2026, 1, 1), 9, 0)
    assert res["overall"]["mae"] == 0 and res["coverage"]["evaluated"] == 48
    assert len(res["byTimeOfDay"]) == 48
    assert sum(b["count"] for b in res["histogram"]) == 48
    hz = analysis.horizon_analysis(ds, date(2026, 1, 1), date(2026, 1, 1))
    assert hz and all(b["mae"] == 0 for b in hz)
