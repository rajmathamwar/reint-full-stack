import pytest
from fastapi.testclient import TestClient

from app import main, store


@pytest.fixture(scope="module")
def client():
    store.reset_dataset(store.synthetic_dataset())
    main._accuracy_cached.cache_clear()
    yield TestClient(main.app)
    store.reset_dataset(None)


def test_health(client):
    assert client.get("/api/health").json() == {"status": "ok"}


def test_meta_flags_synthetic(client):
    j = client.get("/api/meta").json()
    assert j["data"]["synthetic"] is True
    assert j["decisionWindow"] == {"start": "2026-01-01", "end": "2026-01-31"}


def test_decision_shape(client):
    j = client.get("/api/decision/2026-01-15").json()
    assert j["deliveryDate"] == "2026-01-16" and len(j["rows"]) == 48
    assert j["uncertaintyBand"] is not None  # 14 prior days
    assert all(r["publishTime"] <= j["cutoffUtc"] for r in j["rows"] if r["publishTime"])
    first = client.get("/api/decision/2026-01-01").json()
    assert first["uncertaintyBand"] is None  # no history yet -> no band


def test_decision_outside_window_rejected(client):
    assert client.get("/api/decision/2026-02-15").status_code == 422
    assert client.get("/api/decision/not-a-date").status_code == 422


def test_cutoff_changes_the_forecast_used(client):
    early = client.get("/api/decision/2026-01-15?cutoff_hour=0").json()
    late = client.get("/api/decision/2026-01-15?cutoff_hour=12").json()
    assert early["forecastPublishTimes"]["last"] < late["forecastPublishTimes"]["last"]


def test_accuracy(client):
    j = client.get("/api/accuracy").json()
    assert len(j["perDay"]) == 31 and j["overall"]["n"] > 1000
    assert j["overall"]["bias"] > 0  # synthetic generator has a positive (over-forecast) bias


def test_horizon_error_grows_with_lead_time(client):
    b = client.get("/api/horizon").json()["buckets"]
    assert b[0]["mae"] < b[-1]["mae"]


def test_meta_counts_and_quality_endpoint(client):
    m = client.get("/api/meta").json()
    assert m["counts"]["actuals"] == 1536 and m["counts"]["forecasts"] == m["counts"]["forecastRows"] > 1000
    q = client.get("/api/quality").json()
    assert q["actuals"]["expected"] == 1536 and q["expectedEvaluatedPeriods"] == 1488
    assert q["data"]["synthetic"] is True and q["warnings"]


def test_accuracy_evaluates_1488_periods(client):
    assert client.get("/api/accuracy").json()["coverage"]["evaluated"] == 1488
