"""Tests for the Elexon client (mocked HTTP, no network), the quality report and the safe refresh."""
from datetime import date, datetime, timedelta, timezone

import httpx
import pytest

from app import elexon, quality, refresh, store
from app.analysis import Dataset

UTC = timezone.utc


@pytest.fixture(autouse=True)
def no_sleep(monkeypatch):
    monkeypatch.setattr(elexon, "_sleep", lambda s: None)


def client_for(handler):
    return httpx.Client(transport=httpx.MockTransport(handler))


def test_parse_ts_handles_z_suffix():
    assert elexon.parse_ts("2026-01-01T00:30:00Z") == datetime(2026, 1, 1, 0, 30, tzinfo=UTC)


def test_actuals_request_construction_chunking_and_filtering():
    seen = []

    def handler(req):
        seen.append(dict(req.url.params))
        return httpx.Response(200, json=[
            {"fuelType": "WIND", "startTime": "2026-01-01T00:00:00Z", "publishTime": "2026-01-01T00:20:00Z", "generation": 5000},
            {"fuelType": "CCGT", "startTime": "2026-01-01T00:00:00Z", "publishTime": "2026-01-01T00:20:00Z", "generation": 9000},
        ])

    out = elexon.fetch_actuals(client_for(handler), date(2026, 1, 1), date(2026, 1, 10))
    assert len(seen) == 2  # 10 days -> 7 + 3 day chunks
    assert seen[0] == {"settlementDateFrom": "2026-01-01", "settlementDateTo": "2026-01-07", "fuelType": "WIND"}
    assert not any("publishDateTime" in k for p in seen for k in p)  # never mix settlement and publish filters
    assert out == {datetime(2026, 1, 1, tzinfo=UTC): 5000.0}  # CCGT dropped


def test_actuals_duplicate_start_time_keeps_latest_publish():
    rows = [
        {"fuelType": "WIND", "startTime": "2026-01-01T00:00:00Z", "publishTime": "2026-01-01T00:20:00Z", "generation": 100},
        {"fuelType": "WIND", "startTime": "2026-01-01T00:00:00Z", "publishTime": "2026-01-01T01:00:00Z", "generation": 120},
    ]
    out = elexon.fetch_actuals(client_for(lambda r: httpx.Response(200, json=rows)), date(2026, 1, 1), date(2026, 1, 1))
    assert out[datetime(2026, 1, 1, tzinfo=UTC)] == 120.0


def test_actuals_falls_back_when_fueltype_param_rejected():
    calls = []

    def handler(req):
        calls.append("fuelType" in req.url.params)
        if "fuelType" in req.url.params:
            return httpx.Response(400, json={"error": "bad"})
        return httpx.Response(200, json={"data": [{"fuelType": "WIND", "startTime": "2026-01-01T00:00:00Z", "generation": 1}]})

    out = elexon.fetch_actuals(client_for(handler), date(2026, 1, 1), date(2026, 1, 1))
    assert calls == [True, False] and len(out) == 1


def test_forecasts_request_construction_and_history_preserved():
    seen = []

    def handler(req):
        seen.append(dict(req.url.params))
        return httpx.Response(200, json=[
            {"publishTime": "2026-01-01T06:00:00Z", "startTime": "2026-01-02T12:00:00Z", "generation": 4000},
            {"publishTime": "2026-01-01T09:00:00Z", "startTime": "2026-01-02T12:00:00Z", "generation": 4500},  # same target, newer publish
            {"publishTime": "2026-01-01T09:00:00Z", "startTime": "2026-01-02T12:00:00Z", "generation": 4500},  # exact duplicate
        ])

    out = elexon.fetch_forecasts(client_for(handler), datetime(2026, 1, 1, tzinfo=UTC), datetime(2026, 1, 3, tzinfo=UTC))
    assert seen == [{"publishDateTimeFrom": "2026-01-01T00:00:00Z", "publishDateTimeTo": "2026-01-03T00:00:00Z"}]
    assert len(out) == 2  # duplicate removed, BOTH publications kept
    assert [g for _, _, g in out] == [4000.0, 4500.0]


def test_retries_on_503_then_succeeds():
    n = {"c": 0}

    def handler(req):
        n["c"] += 1
        return httpx.Response(503) if n["c"] < 3 else httpx.Response(200, json=[])

    assert elexon._get(client_for(handler), "/x", {}) == [] and n["c"] == 3


def test_gives_up_after_max_attempts():
    with pytest.raises(httpx.HTTPStatusError):
        elexon._get(client_for(lambda r: httpx.Response(503)), "/x", {})


def test_no_retry_on_client_error():
    n = {"c": 0}

    def handler(req):
        n["c"] += 1
        return httpx.Response(400)

    with pytest.raises(httpx.HTTPStatusError):
        elexon._get(client_for(handler), "/x", {})
    assert n["c"] == 1


def test_retries_on_timeout():
    n = {"c": 0}

    def handler(req):
        n["c"] += 1
        if n["c"] == 1:
            raise httpx.ReadTimeout("slow")
        return httpx.Response(200, json=[])

    assert elexon._get(client_for(handler), "/x", {}) == [] and n["c"] == 2


# ----------------------------------------------------------------------------- quality report
def test_quality_report_on_synthetic_flags_it_and_counts_expected():
    q = quality.quality_report(store.synthetic_dataset(), date(2026, 1, 1), date(2026, 1, 31))
    assert q["actuals"]["expected"] == 1536 and q["actuals"]["missing"] == 0
    assert q["expectedEvaluatedPeriods"] == 1488
    assert q["forecasts"]["resolutionMinutes"] == 30
    assert q["forecasts"]["distinctPublishTimes"] > 100
    assert any("SYNTHETIC" in w for w in q["warnings"])


def test_quality_report_flags_single_publish_time_and_hourly_resolution():
    pub = datetime(2026, 1, 1, 6, tzinfo=UTC)
    fcs = [(pub, datetime(2026, 1, 2, h, tzinfo=UTC), 1000.0) for h in range(24)]  # hourly targets, one publication
    q = quality.quality_report(Dataset({}, fcs, meta={}), date(2026, 1, 1), date(2026, 1, 31))
    text = " ".join(q["warnings"])
    assert q["forecasts"]["resolutionMinutes"] == 60
    assert "same publishTime" in text and "60 minutes" in text and "actuals are missing" in text


# ----------------------------------------------------------------------------- refresh safety
def test_refresh_never_overwrites_snapshot_with_empty_data(tmp_path, monkeypatch):
    snap = tmp_path / "snapshot.json"
    snap.write_text('{"keep":"me"}')
    monkeypatch.setattr(store, "SNAPSHOT_PATH", snap)
    monkeypatch.setattr(refresh, "SNAPSHOT_PATH", snap)
    monkeypatch.setattr(refresh, "fetch_live", lambda: Dataset({}, [], meta={}))
    assert refresh.main() == 1
    assert snap.read_text() == '{"keep":"me"}'


def test_refresh_failure_leaves_snapshot_untouched(tmp_path, monkeypatch):
    snap = tmp_path / "snapshot.json"
    snap.write_text("old")
    monkeypatch.setattr(refresh, "SNAPSHOT_PATH", snap)

    def boom():
        raise RuntimeError("network down")

    monkeypatch.setattr(refresh, "fetch_live", boom)
    assert refresh.main() == 1 and snap.read_text() == "old"


def test_refresh_writes_and_snapshot_roundtrips(tmp_path, monkeypatch, capsys):
    snap = tmp_path / "snapshot.json"
    ds = store.synthetic_dataset()
    ds.meta = {"source": "elexon-live", "synthetic": False}
    monkeypatch.setattr(store, "SNAPSHOT_PATH", snap)
    monkeypatch.setattr(refresh, "SNAPSHOT_PATH", snap)
    monkeypatch.setattr(refresh, "fetch_live", lambda: ds)
    assert refresh.main() == 0
    loaded = store.load_snapshot()
    assert len(loaded.actuals) == len(ds.actuals) and len(loaded.forecasts) == len(ds.forecasts)
    assert loaded.meta["synthetic"] is False
    assert "distinct publishTimes" in capsys.readouterr().out
