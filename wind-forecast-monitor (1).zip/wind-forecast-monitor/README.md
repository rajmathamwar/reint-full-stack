# Wind Forecast Monitor

A web portal for a UK utility's **day-ahead power-buying desk**. It answers two questions about GB national wind generation (Elexon data only):

1. **What was the latest wind forecast available when the purchase decision had to be made?**
2. **How accurate are those forecasts, quantitatively — so the desk can plan for the error?**

Scope: purchase decisions made in **January 2026** (delivery days 2 Jan – 1 Feb 2026).

- **Live app:** _add your Vercel URL here_
- **Stack:** React (Vite, Recharts) · Python (FastAPI) · Docker · Vercel

> **AI disclosure:** this project was built with the assistance of Claude (Anthropic). All design decisions, logic and tests were reviewed by the author.

## Key idea: "forecast at decision time"

Day-ahead trades for delivery day *D* are placed on day *D-1*. For each half-hour of *D* the portal selects the **most recent WINDFOR forecast with `publishTime` ≤ the cut-off** (default **09:00 UK time on D-1**, adjustable in the UI), and compares it with the FUELHH `WIND` outturn. Forecasts published after the cut-off are never used — that would leak information the desk did not have.

| Concept | Definition |
|---|---|
| Error | `forecast − actual` (MW). Positive = over-forecast = wind **shortfall** the desk must cover |
| MAE / RMSE | mean absolute / root-mean-square error |
| Bias | mean signed error (systematic over/under-forecasting) |
| wMAPE | Σ\|error\| / Σ actual — a stable percentage for energy data; MAPE ignores periods with actual < 500 MW |
| P90 shortfall | 90th percentile of signed error: wind falls short of forecast by more than this 1 time in 10 |
| P90-safe wind | forecast − P90 shortfall. Wind the desk can rely on with ~90% confidence |

The uncertainty band shown for a decision is learned **only from earlier decisions** in the window (no look-ahead) and appears after 3 days of history.

## Features

- **Decision view** – pick a decision date and cut-off; see the forecast the desk had, its publish times/lead times, an 80% range, the P90-safe wind figure, actual outturn (hide it for a "blind" view), half-hourly table and CSV export.
- **Forecast accuracy** – overall KPIs, error by day, bias by time of day, error distribution, and error vs lead time (how much forecasts improve as delivery approaches).
- **Data status** – live vs synthetic, record counts vs expectations, number of distinct forecast publications, forecast resolution, coverage and automatic warnings (e.g. a single publishTime, hourly resolution, missing periods).
- Transparent data provenance: the UI shows the data snapshot time and **loudly flags synthetic data**.

## Repository layout

```
backend/
  app/
    analysis.py     Pure logic: decision-time selection, metrics, bands, lead-time analysis (no I/O)
    elexon.py       Elexon Insights API client (FUELHH, WINDFOR): chunked, retries/backoff, dedupe
    quality.py      Data-quality report: expected vs actual counts, publication history, resolution, warnings
    store.py        Data loading: snapshot file -> live fetch -> synthetic fallback
    main.py         FastAPI routes (/api/meta, /api/quality, /api/decision/{date}, /api/accuracy, /api/horizon)
    refresh.py      CLI: download January 2026 data into data/snapshot.json (never overwrites with empty data)
    synthetic.py    Deterministic fake data for tests/offline demos only
    config.py       Window, cut-off, thresholds, env vars
  data/             snapshot.json (committed after running refresh)
  tests/            pytest: analysis (hand-computed cases) + API
frontend/src/
  App.jsx, api.js, format.js, styles.css
  components/       DecisionView, AccuracyView, DataStatus, Kpi
api/index.py        Vercel serverless entry (re-exports the FastAPI app)
vercel.json         Vercel build + routing
Dockerfile          Multi-stage: build React, serve it from FastAPI
docker-compose.yml
docs/VIDEO_SCRIPT.md
.github/workflows/ci.yml
```

## Run it

**1. Load the real data (needs internet; one time):**
```bash
cd backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements-dev.txt
python -m app.refresh        # writes backend/data/snapshot.json  — commit this file
```
If no snapshot exists the app fetches live on first request; if that also fails it shows clearly-labelled synthetic data.

**2. Docker (single container, UI + API on :8000):**
```bash
docker compose up --build
# open http://localhost:8000
```

**3. Local development:**
```bash
cd backend && uvicorn app.main:app --reload --port 8000
cd frontend && npm install && npm run dev      # http://localhost:5173 (proxies /api)
```

**What a good refresh looks like** (the command prints this and any warnings):
- ~1,536 actuals (1 Jan – 1 Feb, 32 × 48); accuracy then evaluates ~1,488 half-hours (31 delivery days × 48)
- thousands of forecast rows with many distinct publishTimes (WINDFOR updates up to ~8×/day)
- resolution 30 min. If it reports 60 min, half the half-hour targets have no forecast and are excluded (not interpolated)

`GET /api/meta` should show `"synthetic": false`, `"source": "elexon-live"`; `GET /api/quality` has the full check list.
`/api/health` only proves the server is up, not that real data loaded.

**Tests:** `cd backend && python -m pytest -q` (35 tests: metrics, cut-off/no-look-ahead, BST, mocked Elexon client with retries and dedupe, quality report, safe refresh, API)

## Deploy to Vercel
Import the repo in Vercel (framework preset: *Other*); `vercel.json` handles the build, the Python function and `/api` routing. Make sure `backend/data/snapshot.json` is committed.

## Design notes & limitations
- Only wind, national level, Elexon data — no demand or price, so the app quantifies wind uncertainty rather than the final MW to buy.
- The 09:00 default cut-off is an assumption (adjustable); the real auction gate closure is later.
- Half-hours with no forecast at the cut-off are reported as missing and excluded from metrics (never interpolated); coverage is displayed.
- Pooled error quantiles assume error behaviour is similar across the month; wind-regime-specific bands are a natural next step.
